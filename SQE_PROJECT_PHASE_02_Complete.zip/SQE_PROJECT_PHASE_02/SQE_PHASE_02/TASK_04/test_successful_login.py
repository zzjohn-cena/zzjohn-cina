import unittest
from selenium import webdriver

class TestSuccessfulLogin(unittest.TestCase):

    def setUp(self):
        self.driver = webdriver.Chrome()
        self.driver.get("your_login_page_url")

    def tearDown(self):
        self.driver.quit()

    def test_successful_login(self):
        self.driver.find_element_by_id("username").send_keys("valid_username")
        self.driver.find_element_by_id("password").send_keys("valid_password")
        self.driver.find_element_by_id("submit").click()

if __name__ == '__main__':
    unittest.main()
