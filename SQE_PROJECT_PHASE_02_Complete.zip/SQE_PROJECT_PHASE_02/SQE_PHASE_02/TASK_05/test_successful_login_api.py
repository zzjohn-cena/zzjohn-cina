import unittest
import requests

class TestSuccessfulLoginAPI(unittest.TestCase):

    def test_successful_login_api(self):
        url = 'your_login_api_url'
        data = {'username': 'valid_username', 'password': 'valid_password'}
        response = requests.post(url, data=data)

if __name__ == '__main__':
    unittest.main()
