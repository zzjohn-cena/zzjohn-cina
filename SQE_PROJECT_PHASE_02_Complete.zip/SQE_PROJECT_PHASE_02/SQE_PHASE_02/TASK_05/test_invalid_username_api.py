import unittest
import requests

class TestInvalidUsernameAPI(unittest.TestCase):

    def test_invalid_username_api(self):
        url = 'your_login_api_url'
        data = {'username': 'invalid_username', 'password': 'valid_password'}
        response = requests.post(url, data=data)

if __name__ == '__main__':
    unittest.main()
