import unittest
import requests

class TestEmptyUsernameAPI(unittest.TestCase):

    def test_empty_username_api(self):
        url = 'your_login_api_url'
        data = {'password': 'valid_password'}
        response = requests.post(url, data=data)

if __name__ == '__main__':
    unittest.main()
