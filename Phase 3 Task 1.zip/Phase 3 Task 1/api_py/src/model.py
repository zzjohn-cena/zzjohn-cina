"""
This module defines the Book class and provides sample data for in-memory storage.
"""

class Book:
    """
    Represents a book with attributes such as ID, title, and author.
    """

    def __init__(self, book_id, title, author):
        """
        Initialize a new instance of the Book class.

        Parameters:
        - book_id (int): The unique identifier for the book.
        - title (str): The title of the book.
        - author (str): The author of the book.
        """
        self.id = book_id
        self.title = title
        self.author = author

    def __str__(self):
        """
        Return a string representation of the book.

        Returns:
        - str: String representation of the book.
        """
        return f"Book(id={self.id}, title={self.title}, author={self.author})"

    def to_dict(self):
        """
        Return a dictionary representation of the book.

        Returns:
        - dict: Dictionary representation of the book.
        """
        return {'id': self.id, 'title': self.title, 'author': self.author}

# Sample data (in-memory storage)
books = [
    Book(book_id=1, title="Book 1", author="Author 1"),
    Book(book_id=2, title="Book 2", author="Author 2")
]
